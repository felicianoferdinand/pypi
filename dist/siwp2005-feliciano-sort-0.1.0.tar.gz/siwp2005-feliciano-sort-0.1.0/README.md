# siwp2005-feliciano-sort

This is a Python package containing a collection of sorting algorithms including bubble sort, insertion sort, and quick sort.

## Installation

You can install the package using pip:

